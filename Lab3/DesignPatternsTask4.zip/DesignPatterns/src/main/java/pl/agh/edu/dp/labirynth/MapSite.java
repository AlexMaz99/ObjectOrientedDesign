package pl.agh.edu.dp.labirynth;

public abstract class MapSite {
    public abstract void Enter();
}
