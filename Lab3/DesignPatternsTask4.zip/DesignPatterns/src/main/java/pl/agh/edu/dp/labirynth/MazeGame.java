package pl.agh.edu.dp.labirynth;

import static pl.agh.edu.dp.labirynth.Direction.*;

public class MazeGame {
    public Maze createMaze(StandardMazeBuilder smb) throws Exception {

        Room r1 = new Room(1);
        Room r2 = new Room(2);
        smb.addRoom(r1);
        smb.addRoom(r2);

        smb.createCommonWall(South, r1, r2);
        smb.createDoor(r1, r2);

        return smb.getCurrentMaze();
    }
}
