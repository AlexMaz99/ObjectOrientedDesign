package pl.agh.edu.dp.labirynth;

import lombok.Getter;

@Getter
public class CountingMazeBuilder implements MazeBuilder {

    private int roomsNr;
    private int doorsNr;
    private int wallNr;

    public CountingMazeBuilder() {
        this.roomsNr = 0;
        this.doorsNr = 0;
        this.wallNr = 0;
    }
    
    @Override
    public void addRoom(Room room) {
        roomsNr++;
        wallNr+=4;
    }

    @Override
    public void createDoor(Room r1, Room r2) throws Exception {
        wallNr--;
        doorsNr++;
    }

    @Override
    public void createCommonWall(Direction firstRoomDir, Room r1, Room r2) throws Exception {
        wallNr--;
    }

    public int getCounts(){
        return roomsNr+wallNr+doorsNr;
    }

}
