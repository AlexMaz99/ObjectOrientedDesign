package pl.agh.edu.dp.labirynth;

import java.util.Optional;
import java.util.Vector;

public class Maze {
    private Vector<Room> rooms;

    public Maze() {
        this.rooms = new Vector<Room>();
    }

    public void addRoom(Room room){
        rooms.add(room);
    }

    public Room findRoom(int roomNr) throws Exception {
        Optional<Room> foundRoom =  rooms.stream().filter(room -> room.getRoomNumber() == roomNr).findAny();
        if(foundRoom.isPresent()) return foundRoom.get();
        throw new Exception("Error: Room with that number doesnt exist");
    }

    public void setRooms(Vector<Room> rooms) {
        this.rooms = rooms;
    }

    public int getRoomNumbers()
    {
        return rooms.size();
    }
}
