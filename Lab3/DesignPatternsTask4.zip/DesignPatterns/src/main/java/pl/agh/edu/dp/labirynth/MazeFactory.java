package pl.agh.edu.dp.labirynth;

public class MazeFactory {

    public Maze CreateMazeFromFile(String FileName){
        return  null;
    }


}
